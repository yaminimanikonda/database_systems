INSERT INTO region VALUES   
        ( 1  
        , 'Europe'   
        );  
  
INSERT INTO region VALUES   
        ( 2  
        , 'America'   
        );  
  
INSERT INTO region VALUES   
        ( 3  
        , 'Asia'   
        );  
  
INSERT INTO region VALUES   
        ( 4  
        , 'Middle East and Africa'   
        );  
        
select * from region;