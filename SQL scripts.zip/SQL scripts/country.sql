-- insert data into the country table 
 
INSERT INTO country VALUES   ( 'IT'  , 'Italy'  , 1   );  
INSERT INTO country VALUES   ( 'JP'  , 'Japan'  , 3   );  
INSERT INTO country VALUES   ( 'US'  , 'United States of America'  , 2   );  
INSERT INTO country VALUES   ( 'CA'  , 'Canada'  , 2   );  
INSERT INTO country VALUES   ( 'CN'  , 'China'  , 3   );  
INSERT INTO country VALUES   ( 'IN'  , 'India'  , 3   );  
INSERT INTO country VALUES   ( 'AU'  , 'Australia'  , 3 );    
INSERT INTO country VALUES   ( 'ZW'  , 'Zimbabwe'  , 4   );  
INSERT INTO country VALUES   ( 'SG'  , 'Singapore'  , 3   );  
INSERT INTO country VALUES   ( 'UK'  , 'United Kingdom'  , 1   );  
INSERT INTO country VALUES   ( 'FR'  , 'France'  , 1   );  
INSERT INTO country VALUES   ( 'DE'  , 'Germany'  , 1   );    
INSERT INTO country VALUES   ( 'ZM'  , 'Zambia'  , 4   );  
INSERT INTO country VALUES   ( 'EG'  , 'Egypt'  , 4   );  
INSERT INTO country VALUES   ( 'BR'  , 'Brazil'  , 2   );  
INSERT INTO country VALUES   ( 'CH'  , 'Switzerland'  , 1   );  
INSERT INTO country VALUES   ( 'NL'  , 'Netherlands'  , 1   );  
INSERT INTO country VALUES   ( 'MX'  , 'Mexico'  , 2   );  
INSERT INTO country VALUES   ( 'KW'  , 'Kuwait'  , 4   );  
INSERT INTO country VALUES   ( 'IL'  , 'Israel'  , 4   );  
INSERT INTO country VALUES   ( 'DK'  , 'Denmark'  , 1   );  
INSERT INTO country VALUES   ( 'ML'  , 'Malaysia'  , 3   );  
INSERT INTO country VALUES   ( 'NG'  , 'Nigeria'  , 4   );  
INSERT INTO country VALUES   ( 'AR'  , 'Argentina'  , 2   );  
INSERT INTO country VALUES   ( 'BE'  , 'Belgium'  , 1   );  
        
select * from country;