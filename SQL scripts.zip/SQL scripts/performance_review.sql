INSERT INTO performance_review  VALUES (1,'2024-01-15',4.5,'Good communication',198);
INSERT INTO performance_review  VALUES (2,'2024-01-16',4.5,'Needs improvement',199);
INSERT INTO performance_review  VALUES (3,'2024-01-17',4.5,'Exceeds expectations',200);
INSERT INTO performance_review  VALUES (4,'2024-01-18',5,'Needs improvement',201);
INSERT INTO performance_review  VALUES (5,'2024-01-19',4.8,'Exceeds expectations',202);
INSERT INTO performance_review  VALUES (6,'2024-01-20',4.5,'Good communication',203);
INSERT INTO performance_review  VALUES (7,'2024-01-21',5,'Exceeds expectations',204);
INSERT INTO performance_review  VALUES (8,'2024-01-22',4.5,'Needs improvement',205);
INSERT INTO performance_review  VALUES (9,'2024-01-23',4.9,'Good communication',206);
INSERT INTO performance_review  VALUES (10,'2024-01-24',4.5,'Needs improvement',100);
INSERT INTO performance_review  VALUES (11,'2024-01-25',4.5,'Exceeds expectations',101);
INSERT INTO performance_review  VALUES (12,'2024-01-26',4.5,'Good communication',102);
INSERT INTO performance_review  VALUES (13,'2024-01-27',4.3,'Exceeds expectations',103);
INSERT INTO performance_review  VALUES (14,'2024-01-28',4.5,'Needs improvement',104);
INSERT INTO performance_review  VALUES (15,'2024-01-29',4.5,'Exceeds expectations',105);

select * from performance_review;
